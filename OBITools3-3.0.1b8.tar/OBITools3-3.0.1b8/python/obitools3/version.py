major = 3
minor = 0
serial= '1b8'

version ="%d.%d.%s" % (major,minor,serial)
