/****************************************************************************
 * Code for obi errnos                                                      *
 ****************************************************************************/

/**
 * @file obierrno.c
 * @author Eric Coissac (eric.coissac@metabarcoding.org)
 * @date 23 May 2015
 * @brief Code for obi errnos.
 */


int obi_errno = 0;

